import { useEffect, useState } from "react";
import { createClient } from "@supabase/supabase-js";
import {
  Scan, Menu, UserRound, BookOpen, Plus, MoreVertical, Moon, BedDouble,
  ClipboardList, Compass, House, ChevronRight, CircleHelp, ShieldCheck,
  LogOut, X, Play, Clock3, FileText, Settings, Activity, CalendarDays
} from "lucide-react";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
const supabase = supabaseUrl && supabaseKey ? createClient(supabaseUrl, supabaseKey) : null;
const today = () => new Intl.DateTimeFormat(undefined, { weekday: "short", month: "short", day: "numeric" }).format(new Date());

const learnItems = [
  { title: "What affects reproductive health?", category: "Basics", duration: "4 min", description: "A careful introduction to factors that may influence reproductive health." },
  { title: "Understanding sperm motility", category: "Science", duration: "5 min", description: "What motility means and how laboratories assess it." },
  { title: "Myths vs. facts", category: "Myths", duration: "3 min", description: "Why appearance and lifestyle questionnaires cannot diagnose infertility." },
  { title: "Sleep, stress and health", category: "Lifestyle", duration: "4 min", description: "How everyday health patterns fit into a bigger picture." }
];

function Logo({ size = 42 }) {
  return <svg width={size} height={size} viewBox="0 0 100 100" fill="none" aria-label="Nuvora logo">
    <path d="M16 31V18Q16 12 23 12H36M64 12H77Q84 12 84 19V31M16 69V82Q16 88 23 88H36M64 88H77Q84 88 84 81V69" stroke="currentColor" strokeWidth="5" strokeLinecap="round"/>
    <ellipse cx="49" cy="50" rx="27" ry="17" transform="rotate(-32 49 50)" stroke="currentColor" strokeWidth="4"/>
    <circle cx="46" cy="50" r="8" fill="currentColor"/><circle cx="70" cy="34" r="3.5" fill="currentColor"/>
  </svg>;
}

function Loading() {
  return <div className="splash"><Logo size={96}/><div className="splash-name">NUVORA</div><p>Your reproductive health, better understood.</p><div className="loading-line"><i /></div></div>;
}

function Auth({ onSignedIn }) {
  const [mode, setMode] = useState("signup");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [country, setCountry] = useState("India");
  const [dob, setDob] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");

  async function submit(e) {
    e.preventDefault(); setError(""); setNotice(""); setBusy(true);
    try {
      if (!supabase) throw new Error("The database isn't connected yet. Add your Supabase URL and publishable/anon key to .env.local, then restart the site.");
      if (mode === "signup") {
        if (!dob || !country) throw new Error("Please choose your country and date of birth.");
        const birth = new Date(dob + "T00:00:00");
        if (birth > new Date()) throw new Error("Date of birth can't be in the future.");
        const age = (Date.now() - birth.getTime()) / 31557600000;
        if (age < 13) throw new Error("This demo is not available for users under 13.");
        const { data, error: signError } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: { data: { country, date_of_birth: dob } }
        });
        if (signError) throw signError;
        if (data.session) onSignedIn(data.session.user);
        else setNotice("Check your email to confirm your account, then sign in. Your assigned Nuvora ID appears after your profile is created.");
      } else {
        const { data, error: signError } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (signError) throw signError;
        onSignedIn(data.user);
      }
    } catch (err) { setError(err.message || "Something went wrong."); }
    finally { setBusy(false); }
  }

  return <main className="auth-wrap">
    <div className="auth-card">
      <div className="auth-brand"><Logo size={62}/><div><div className="wordmark">NUVORA</div><div className="tagline">BETTER INSIGHTS. HEALTHIER TOMORROWS.</div></div></div>
      <h1>{mode === "signup" ? "Create your account" : "Welcome back"}</h1>
      <p className="muted">{mode === "signup" ? "Your private space for health education and check-ins." : "Sign in to continue to your dashboard."}</p>
      <form onSubmit={submit} className="form">
        <label>Email address<input type="email" autoComplete="email" value={email} onChange={e=>setEmail(e.target.value)} required placeholder="you@example.com"/></label>
        <label>Password<input type="password" autoComplete={mode === "signup" ? "new-password" : "current-password"} value={password} onChange={e=>setPassword(e.target.value)} required minLength={8} placeholder="At least 8 characters"/></label>
        {mode === "signup" && <>
          <label>Country<select value={country} onChange={e=>setCountry(e.target.value)} required>
            {["India","United States","United Kingdom","Canada","Australia","Other"].map(c=><option key={c}>{c}</option>)}
          </select></label>
          <label>Date of birth<input type="date" value={dob} onChange={e=>setDob(e.target.value)} required max={new Date().toISOString().slice(0,10)}/></label>
          <p className="fineprint">Your date of birth is private. Nuvora is a health education and tracking prototype, not a diagnostic service.</p>
        </>}
        {error && <div className="alert error">{error}</div>}
        {notice && <div className="alert">{notice}</div>}
        <button className="primary full" disabled={busy}>{busy ? "Please wait…" : mode === "signup" ? "Create account" : "Sign in"}</button>
      </form>
      <button className="link-btn" onClick={()=>{setMode(mode === "signup" ? "login" : "signup");setError("");setNotice("");}}>
        {mode === "signup" ? "Already have an account? Sign in" : "New to Nuvora? Create an account"}
      </button>
      <div className="secure-note"><ShieldCheck size={15}/> Your password is handled by the authentication provider, not stored by this app.</div>
    </div>
  </main>;
}

function App() {
  const [sessionUser, setSessionUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState(null);
  const [tab, setTab] = useState("Home");
  const [drawer, setDrawer] = useState(false);
  const [modal, setModal] = useState("");
  const [toast, setToast] = useState("");
  const [sleepHours, setSleepHours] = useState("8");
  const [sleepDate, setSleepDate] = useState(new Date().toISOString().slice(0,10));
  const [sleepLogs, setSleepLogs] = useState([]);
  const [habit, setHabit] = useState("No");
  const [habitFrequency, setHabitFrequency] = useState("Occasionally");
  const [habitType, setHabitType] = useState("Tobacco");
  const [habitLogs, setHabitLogs] = useState([]);
  const [records, setRecords] = useState([]);
  const [video, setVideo] = useState(null);

  function say(message) { setToast(message); window.setTimeout(()=>setToast(""), 3200); }

  useEffect(() => {
    let alive = true;
    async function init() {
      if (supabase) {
        const { data } = await supabase.auth.getSession();
        if (alive && data.session?.user) setSessionUser(data.session.user);
        supabase.auth.onAuthStateChange((_event, session) => {
          if (alive) setSessionUser(session?.user || null);
        });
      }
      if (alive) setLoading(false);
    }
    init();
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    if (!supabase || !sessionUser) { setProfile(null); return; }
    let alive = true;
    async function fetchData() {
      const [p, s, h, r] = await Promise.all([
        supabase.from("profiles").select("username,country,date_of_birth").eq("id", sessionUser.id).maybeSingle(),
        supabase.from("sleep_logs").select("id,log_date,hours,created_at").order("log_date",{ascending:false}).limit(7),
        supabase.from("habit_logs").select("id,habit,frequency,created_at").order("created_at",{ascending:false}).limit(10),
        supabase.from("check_ins").select("id,created_at,note").order("created_at",{ascending:false}).limit(10)
      ]);
      if (!alive) return;
      if (p.data) setProfile(p.data);
      if (s.data) setSleepLogs(s.data);
      if (h.data) setHabitLogs(h.data);
      if (r.data) setRecords(r.data);
    }
    fetchData();
    return () => { alive = false; };
  }, [sessionUser]);

  async function saveSleep(e) {
    e.preventDefault();
    const hours = Number(sleepHours);
    if (!Number.isFinite(hours) || hours < 0 || hours > 24) return say("Enter sleep hours between 0 and 24.");
    if (supabase && sessionUser) {
      const { error } = await supabase.from("sleep_logs").insert({ user_id: sessionUser.id, log_date: sleepDate, hours });
      if (error) return say("Couldn't save sleep log: " + error.message);
      const { data } = await supabase.from("sleep_logs").select("id,log_date,hours,created_at").order("log_date",{ascending:false}).limit(7);
      setSleepLogs(data || []);
    } else {
      setSleepLogs(prev=>[{id:crypto.randomUUID(),log_date:sleepDate,hours},...prev.filter(x=>x.log_date!==sleepDate)].slice(0,7));
    }
    setModal(""); say("Sleep log saved.");
  }

  async function saveHabit(e) {
    e.preventDefault();
    if (supabase && sessionUser) {
      const { error } = await supabase.from("habit_logs").insert({user_id:sessionUser.id,habit:habit === "Yes" ? habitType : "None reported",frequency:habit === "Yes" ? habitFrequency : "Not applicable"});
      if (error) return say("Couldn't save check-in: " + error.message);
      const { data } = await supabase.from("habit_logs").select("id,habit,frequency,created_at").order("created_at",{ascending:false}).limit(10);
      setHabitLogs(data || []);
    } else {
      setHabitLogs(prev=>[{id:crypto.randomUUID(),habit:habit === "Yes" ? habitType : "None reported",frequency:habit === "Yes" ? habitFrequency : "Not applicable",created_at:new Date().toISOString()},...prev].slice(0,10));
    }
    setModal(""); say("Lifestyle check-in saved.");
  }

  async function logout() {
    if (supabase) await supabase.auth.signOut();
    setSessionUser(null); setProfile(null); setTab("Home"); setDrawer(false); say("Signed out.");
  }

  if (loading) return <Loading />;
  if (!sessionUser) return <><div className="splash splash-short"><Logo size={70}/><div className="splash-name">NUVORA</div><p>Your reproductive health, better understood.</p></div><Auth onSignedIn={setSessionUser}/></>;

  const username = profile?.username || sessionUser.user_metadata?.username || "User";
  const hasRealBackend = Boolean(supabase);

  function addCheckIn() {
    setModal("checkin");
  }

  async function saveNote(e) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const note = String(form.get("note") || "").trim();
    if (supabase && sessionUser) {
      const { error } = await supabase.from("check_ins").insert({user_id:sessionUser.id,note:note || "Weekly check-in completed"});
      if (error) return say("Couldn't save report: " + error.message);
      const { data } = await supabase.from("check_ins").select("id,created_at,note").order("created_at",{ascending:false}).limit(10);
      setRecords(data || []);
    } else {
      setRecords(prev=>[{id:crypto.randomUUID(),created_at:new Date().toISOString(),note:note || "Weekly check-in completed"},...prev].slice(0,10));
    }
    setModal(""); say("Weekly report note saved.");
  }

  return <div className="app-shell">
    <header className="topbar">
      <div className="left-top">
        <button className="icon-button" aria-label="Open menu" onClick={()=>setDrawer(true)}><Menu/></button>
        <button className="icon-button profile-button" aria-label="Profile" onClick={()=>setTab("Profile")}><UserRound/></button>
      </div>
      <div className="top-brand"><Logo size={35}/><span className="wordmark">NUVORA</span></div>
      <div className="top-actions">
        <button className="icon-button" aria-label="Learn" onClick={()=>setTab("Learn")}><BookOpen/></button>
        <button className="icon-button" aria-label="New check-in" onClick={addCheckIn}><Plus/></button>
        <button className="icon-button" aria-label="More options" onClick={()=>setDrawer(true)}><MoreVertical/></button>
      </div>
    </header>

    {drawer && <div className="drawer-backdrop" onClick={()=>setDrawer(false)}><aside className="drawer" onClick={e=>e.stopPropagation()}><div className="drawer-head"><div className="auth-brand"><Logo/><span className="wordmark">NUVORA</span></div><button className="icon-button" onClick={()=>setDrawer(false)}><X/></button></div><p className="muted">{username}</p>{["Home","Records","Scan","Learn","Profile"].map(t=><button className="drawer-item" key={t} onClick={()=>{setTab(t);setDrawer(false)}}>{t}<ChevronRight size={17}/></button>)}<button className="drawer-item" onClick={logout}><LogOut size={17}/> Sign out</button><p className="fineprint">Privacy first. Use only information you are comfortable storing.</p></aside></div>}

    <main className="content">
      {tab === "Home" && <>
        <section className="welcome"><div><div className="eyebrow">PERSONAL DASHBOARD</div><h1>Good to see you, <span>{username}</span>.</h1><p className="muted">Small steps. Better understanding.</p></div><div className="date-label"><CalendarDays size={15}/>{today()}</div></section>
        <section className="home-grid">
          <article className="card scan-card">
            <div className="eyebrow">YOUR NEXT CHECK-IN</div><h2>Scan</h2><p className="muted">A guided experience for learning about reproductive health.</p>
            <div className="scan-graphic"><Logo size={120}/></div>
            <button className="primary full" onClick={()=>setTab("Scan")}>Start scan <Scan size={17}/></button>
            <p className="fineprint">A normal phone camera cannot diagnose sperm health. This scan area is a placeholder until suitable imaging and validation exist.</p>
          </article>
          <div className="side-cards">
            <button className="card mini-card" onClick={()=>setModal("sleep")}><span className="tile-icon"><BedDouble/></span><span className="mini-copy"><strong>Track sleep</strong><small>{sleepLogs[0] ? `${sleepLogs[0].hours} hours logged · ${sleepLogs[0].log_date}` : "Log your sleep and view patterns."}</small></span><ChevronRight className="chevron"/></button>
            <button className="card mini-card" onClick={()=>setModal("habits")}><span className="tile-icon"><Activity/></span><span className="mini-copy"><strong>Lifestyle & health</strong><small>Optional check-in on lifestyle habits.</small></span><ChevronRight className="chevron"/></button>
          </div>
        </section>
        <section className="card report-card">
          <div className="section-title"><h2>Weekly report</h2><button className="text-button" onClick={()=>setTab("Records")}>View records <ChevronRight size={15}/></button></div>
          <div className="report-grid"><div className="report-panel"><span className="eyebrow">CHECK-INS</span><strong>{records.length + sleepLogs.length + habitLogs.length}</strong><p className="muted">Saved entries in recent history</p></div><div className="report-panel note-panel"><span className="eyebrow">YOUR NOTE</span><p>{records[0]?.note || "Add a weekly note to keep track of questions or observations."}</p><button className="outline" onClick={addCheckIn}>Add note</button></div></div>
        </section>
        <section className="learn-section">
          <div className="section-title"><h2>Education videos</h2><button className="text-button" onClick={()=>setTab("Learn")}>Explore all <ChevronRight size={15}/></button></div>
          <div className="video-grid">{learnItems.slice(0,3).map((item,i)=><button className="video-card" key={item.title} onClick={()=>{setVideo(item);setModal("video")}}><div className={`video-thumb thumb-${i}`}><span className="play-circle"><Play size={18} fill="currentColor"/></span></div><strong>{item.title}</strong><small>{item.category} · {item.duration}</small></button>)}</div>
        </section>
      </>}

      {tab === "Records" && <section className="page-section"><div className="eyebrow">YOUR HISTORY</div><h1>Records</h1><p className="muted">Your saved sleep logs, lifestyle check-ins and weekly notes.</p><div className="card record-list"><h2>Sleep logs</h2>{sleepLogs.length ? sleepLogs.map(x=><div className="record-row" key={x.id}><BedDouble/><div><strong>{x.hours} hours of sleep</strong><small>{x.log_date}</small></div></div>) : <p className="muted">No sleep logs yet.</p>}<h2>Lifestyle check-ins</h2>{habitLogs.length ? habitLogs.map(x=><div className="record-row" key={x.id}><ClipboardList/><div><strong>{x.habit}</strong><small>{x.frequency} · {new Date(x.created_at).toLocaleDateString()}</small></div></div>) : <p className="muted">No lifestyle check-ins yet.</p>}<h2>Weekly notes</h2>{records.length ? records.map(x=><div className="record-row" key={x.id}><FileText/><div><strong>{x.note}</strong><small>{new Date(x.created_at).toLocaleDateString()}</small></div></div>) : <p className="muted">No notes yet.</p>}</div></section>}

      {tab === "Scan" && <section className="page-section"><div className="eyebrow">GUIDED FEATURE</div><h1>Scan</h1><div className="card scan-info"><div className="scan-graphic"><Logo size={125}/></div><h2>Imaging isn't connected yet</h2><p className="muted">A phone-only camera cannot reliably resolve and measure individual sperm cells. This feature must not display a fertility score until suitable imaging is available and the analysis is clinically validated.</p><button className="outline" onClick={()=>setTab("Learn")}>Learn about the science <BookOpen size={16}/></button></div></section>}

      {tab === "Learn" && <section className="page-section"><div className="eyebrow">SCIENCE, WITHOUT THE HYPE</div><h1>Learn</h1><p className="muted">Educational summaries for general information, not diagnosis.</p><div className="learn-list">{learnItems.map(item=><button className="card learn-row" key={item.title} onClick={()=>{setVideo(item);setModal("video")}}><div className="tile-icon"><Play/></div><div><strong>{item.title}</strong><small>{item.category} · {item.duration}</small><p className="muted">{item.description}</p></div><ChevronRight/></button>)}</div></section>}

      {tab === "Profile" && <section className="page-section"><div className="eyebrow">ACCOUNT</div><h1>Profile</h1><div className="card profile-card"><div className="profile-avatar"><UserRound size={35}/></div><h2>{username}</h2><p className="muted">{sessionUser.email}</p><div className="profile-detail"><span>Country</span><strong>{profile?.country || sessionUser.user_metadata?.country || "Not set"}</strong></div><div className="profile-detail"><span>Date of birth</span><strong>{profile?.date_of_birth || sessionUser.user_metadata?.date_of_birth || "Not set"}</strong></div><div className="profile-detail"><span>Account ID</span><strong className="id-text">{sessionUser.id.slice(0,8).toUpperCase()}</strong></div><button className="outline full" onClick={logout}><LogOut size={16}/> Sign out</button></div><p className="fineprint">Avoid storing unnecessary intimate or identifying information. This prototype doesn't offer medical diagnosis.</p></section>}
    </main>

    <nav className="bottom-nav" aria-label="Main navigation">
      {[["Records",ClipboardList],["Scan",Scan],["Learn",Compass],["Home",House]].map(([name,Icon])=><button key={name} className={tab===name?"active":""} onClick={()=>setTab(name)}><Icon size={21}/><span>{name === "Learn" ? "Discover" : name}</span></button>)}
    </nav>
    <footer className="footer-note">NUVORA · Health education and tracking prototype. Not a medical diagnostic tool.</footer>

    {modal && <div className="modal-backdrop" onClick={()=>setModal("")}><section className="modal" onClick={e=>e.stopPropagation()}><div className="modal-head"><h2>{modal==="sleep"?"Track sleep":modal==="habits"?"Lifestyle check-in":modal==="checkin"?"Weekly report note":modal==="video"?(video?.title || "Learn"):"Nuvora"}</h2><button className="icon-button" onClick={()=>setModal("")}><X/></button></div>
      {modal==="sleep" && <form className="form" onSubmit={saveSleep}><p className="muted">Log how long you slept. This is a personal record, not a fertility measurement.</p><label>Date<input type="date" value={sleepDate} onChange={e=>setSleepDate(e.target.value)} required max={new Date().toISOString().slice(0,10)}/></label><label>Hours slept<input type="number" min="0" max="24" step=".25" value={sleepHours} onChange={e=>setSleepHours(e.target.value)} required/></label><button className="primary full">Save sleep log</button></form>}
      {modal==="habits" && <form className="form" onSubmit={saveHabit}><p className="muted">Optional and non-judgmental. This records self-reported habits and cannot diagnose fertility.</p><label>Do you want to record a habit today?<select value={habit} onChange={e=>setHabit(e.target.value)}><option>No</option><option>Yes</option></select></label>{habit==="Yes" && <><label>Habit<select value={habitType} onChange={e=>setHabitType(e.target.value)}><option>Tobacco</option><option>Alcohol</option><option>Cannabis or other substance</option><option>Other lifestyle factor</option></select></label><label>Frequency<select value={habitFrequency} onChange={e=>setHabitFrequency(e.target.value)}><option>Daily</option><option>Several times a week</option><option>Weekly</option><option>Monthly</option><option>Occasionally</option></select></label></>}<button className="primary full">Save check-in</button></form>}
      {modal==="checkin" && <form className="form" onSubmit={saveNote}><p className="muted">Keep this note general. Please don't include highly sensitive details.</p><label>Note<textarea name="note" rows="4" maxLength="500" placeholder="Questions, observations or something to discuss with a healthcare professional…"/></label><button className="primary full">Save note</button></form>}
      {modal==="video" && <div className="video-detail"><div className="video-placeholder"><Play size={28}/><span>Educational content preview</span></div><div className="eyebrow">{video?.category} · {video?.duration}</div><p>{video?.description}</p><p className="muted">Video playback will be connected when a reviewed educational library is added. Content should rely on reputable medical sources.</p><button className="outline full" onClick={()=>setModal("")}>Close</button></div>}
    </section></div>}
    {toast && <div className="toast" role="status">{toast}</div>}
  </div>;
}

export default App;