-- Nuvora database schema for Supabase.
-- Run this in Supabase Dashboard > SQL Editor.
-- Do not place service-role keys in frontend code.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  country text,
  date_of_birth date,
  created_at timestamptz not null default now()
);

create sequence if not exists public.nuvora_user_number_seq start 1;

create or replace function public.create_nuvora_profile()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  next_num bigint;
begin
  next_num := nextval('public.nuvora_user_number_seq');
  insert into public.profiles (id, username, country, date_of_birth)
  values (
    new.id,
    'user-' || next_num,
    nullif(new.raw_user_meta_data->>'country', ''),
    nullif(new.raw_user_meta_data->>'date_of_birth', '')::date
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_nuvora_user_created on auth.users;
create trigger on_nuvora_user_created
after insert on auth.users
for each row execute procedure public.create_nuvora_profile();

create table if not exists public.sleep_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  log_date date not null,
  hours numeric(4,2) not null check (hours >= 0 and hours <= 24),
  created_at timestamptz not null default now(),
  unique(user_id, log_date)
);

create table if not exists public.habit_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  habit text not null,
  frequency text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.check_ins (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  note text not null default '',
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.sleep_logs enable row level security;
alter table public.habit_logs enable row level security;
alter table public.check_ins enable row level security;

drop policy if exists "read own profile" on public.profiles;
create policy "read own profile" on public.profiles for select to authenticated using (auth.uid() = id);
drop policy if exists "update own profile" on public.profiles;
create policy "update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "read own sleep logs" on public.sleep_logs;
create policy "read own sleep logs" on public.sleep_logs for select to authenticated using (auth.uid() = user_id);
drop policy if exists "insert own sleep logs" on public.sleep_logs;
create policy "insert own sleep logs" on public.sleep_logs for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "delete own sleep logs" on public.sleep_logs;
create policy "delete own sleep logs" on public.sleep_logs for delete to authenticated using (auth.uid() = user_id);
drop policy if exists "read own habit logs" on public.habit_logs;
create policy "read own habit logs" on public.habit_logs for select to authenticated using (auth.uid() = user_id);
drop policy if exists "insert own habit logs" on public.habit_logs;
create policy "insert own habit logs" on public.habit_logs for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "delete own habit logs" on public.habit_logs;
create policy "delete own habit logs" on public.habit_logs for delete to authenticated using (auth.uid() = user_id);
drop policy if exists "read own check-ins" on public.check_ins;
create policy "read own check-ins" on public.check_ins for select to authenticated using (auth.uid() = user_id);
drop policy if exists "insert own check-ins" on public.check_ins;
create policy "insert own check-ins" on public.check_ins for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "delete own check-ins" on public.check_ins;
create policy "delete own check-ins" on public.check_ins for delete to authenticated using (auth.uid() = user_id);

grant usage on schema public to authenticated;
grant select, update on public.profiles to authenticated;
grant select, insert, delete on public.sleep_logs to authenticated;
grant select, insert, delete on public.habit_logs to authenticated;
grant select, insert, delete on public.check_ins to authenticated;
