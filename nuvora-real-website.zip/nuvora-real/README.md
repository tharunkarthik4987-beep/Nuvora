# Nuvora — real website starter

A deployable React + Vite frontend with Supabase Auth and Postgres for private per-user records. The design follows the supplied sketch: large Scan card at left, Sleep and Lifestyle cards stacked at right, Weekly Report below, and bottom navigation for Records, Scan, Discover, Home. The UI is monochrome.

## Important limits
- The frontend is implemented; a public production website still requires you to create/configure Supabase and a hosting project.
- Scan is deliberately a placeholder. A phone-only camera cannot reliably measure sperm health. Do not represent a scan or lifestyle questionnaire as an infertility diagnosis.
- This project collects date of birth and health-related logs. Before real public use, review privacy requirements, add a privacy notice and retention/deletion flows, and test the security policies.
- Account signup uses email + password for account verification/recovery. The database assigns sequential display IDs (`user-1`, `user-2`, …). The sequence is public-facing and must not be treated as a secret or security credential.
- The frontend includes local-only check-in behavior if Supabase is not configured, but local demo entries disappear on refresh. Real persistence requires Supabase setup.

## 1. Run locally
Install Node.js 20+ and then:

```bash
npm install
cp .env.example .env.local
```

Edit `.env.local` and add your Supabase project URL and publishable/anon key. Do not use the Supabase service-role key in frontend variables.

Run:

```bash
npm run dev
```

## 2. Configure Supabase
1. Create a project at https://supabase.com/.
2. In Project Settings / API, copy the Project URL and publishable/anon key into `.env.local`.
3. In SQL Editor, run all of `supabase/schema.sql`.
4. In Authentication settings, configure the Site URL and allowed redirect URLs for local development and your deployed site.
5. Keep email confirmation enabled for real users. Test sign-up, email confirmation, sign-in, and sign-out.
6. Review RLS policies before adding any new tables or fields. Never expose the service-role key.

## 3. Deploy the live site
1. Push this folder to a private GitHub repository.
2. Create a Vercel project and import the repository (or use another static hosting provider).
3. Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in the hosting project's environment variables.
4. Deploy, then add the deployed URL to Supabase Auth's Site URL and Redirect URLs.
5. Test account creation and data isolation with two separate test accounts.

Vite outputs static files to `dist/`; the hosting provider serves them. Supabase is the database/auth service.

## Current implemented flows
- Sign up / sign in through Supabase Auth.
- Country and date-of-birth onboarding metadata.
- Database-generated `user-N` display IDs through an auth trigger.
- Dashboard in the hand-drawn layout.
- Create and view sleep logs.
- Create and view lifestyle check-ins.
- Save and view weekly notes.
- Records, Scan, Discover, Home, Profile and drawer navigation.
- Educational content placeholders with clear indication that real reviewed video content must be added.

## Before launch
- Add password reset flow.
- Add user-controlled account/data deletion.
- Add clear consent and privacy policy.
- Add rate limits / abuse monitoring where appropriate.
- Confirm age policy and jurisdiction-specific requirements.
- Do not collect intimate images until secure handling, consent, and clinical validation are designed.
